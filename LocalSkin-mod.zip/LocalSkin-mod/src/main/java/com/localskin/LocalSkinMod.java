package com.localskin;

import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.util.Identifier;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * Общая часть мода. Если этот же мод стоит на сервере (или это одиночная игра / LAN),
 * сервер просто пересылает скины между клиентами, у которых есть мод.
 * Скины хранятся только в памяти сервера, на диск сервер ничего не пишет.
 */
public class LocalSkinMod implements ModInitializer {
    public static final String MOD_ID = "localskin";

    /** клиент -> сервер: "я поставил скин" (model, png). Пустой png = сброс. */
    public static final Identifier SET = new Identifier(MOD_ID, "set");
    /** клиент -> сервер: "я зашёл, пришли мне чужие скины" */
    public static final Identifier HELLO = new Identifier(MOD_ID, "hello");
    /** сервер -> клиент: (uuid, model, png). Пустой png = сброс. */
    public static final Identifier SYNC = new Identifier(MOD_ID, "sync");

    /** Пакет клиент->сервер ограничен ~32 КБ, поэтому png ограничен 30000 байт. */
    public static final int MAX_BYTES = 30000;

    private record Stored(String model, byte[] data) {}

    private static final Map<UUID, Stored> STORED = new HashMap<>();

    @Override
    public void onInitialize() {
        ServerPlayNetworking.registerGlobalReceiver(HELLO, (server, player, handler, buf, responseSender) ->
                server.execute(() -> {
                    for (Map.Entry<UUID, Stored> e : STORED.entrySet()) {
                        if (e.getKey().equals(player.getUuid())) continue;
                        sendSync(player, e.getKey(), e.getValue().model(), e.getValue().data());
                    }
                }));

        ServerPlayNetworking.registerGlobalReceiver(SET, (server, player, handler, buf, responseSender) -> {
            String rawModel = buf.readString(16);
            byte[] data = buf.readByteArray(MAX_BYTES);
            server.execute(() -> {
                String model = "slim".equals(rawModel) ? "slim" : "default";
                UUID uuid = player.getUuid();
                if (data.length == 0) {
                    STORED.remove(uuid);
                    broadcast(server, player, uuid, model, new byte[0]);
                    return;
                }
                if (!looksLikePng(data)) return;
                STORED.put(uuid, new Stored(model, data));
                broadcast(server, player, uuid, model, data);
            });
        });

        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.player.getUuid();
            if (STORED.remove(uuid) != null) {
                broadcast(server, handler.player, uuid, "default", new byte[0]);
            }
        });

        ServerLifecycleEvents.SERVER_STOPPED.register(server -> STORED.clear());
    }

    private static boolean looksLikePng(byte[] d) {
        return d.length > 8 && d[0] == (byte) 0x89 && d[1] == 'P' && d[2] == 'N' && d[3] == 'G';
    }

    private static void broadcast(MinecraftServer server, ServerPlayerEntity except, UUID uuid, String model, byte[] data) {
        for (ServerPlayerEntity p : server.getPlayerManager().getPlayerList()) {
            if (p == except) continue;
            if (ServerPlayNetworking.canSend(p, SYNC)) {
                sendSync(p, uuid, model, data);
            }
        }
    }

    private static void sendSync(ServerPlayerEntity to, UUID uuid, String model, byte[] data) {
        PacketByteBuf out = PacketByteBufs.create();
        out.writeUuid(uuid);
        out.writeString(model);
        out.writeByteArray(data);
        ServerPlayNetworking.send(to, SYNC, out);
    }
}
