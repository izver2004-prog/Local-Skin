package com.localskin.mixin;

import com.localskin.client.SkinManager;
import net.minecraft.client.network.AbstractClientPlayerEntity;
import net.minecraft.util.Identifier;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(AbstractClientPlayerEntity.class)
public abstract class AbstractClientPlayerEntityMixin {
    @Inject(method = "getSkinTexture", at = @At("HEAD"), cancellable = true)
    private void localskin$texture(CallbackInfoReturnable<Identifier> cir) {
        Identifier id = SkinManager.getTexture(((AbstractClientPlayerEntity) (Object) this).getUuid());
        if (id != null) cir.setReturnValue(id);
    }

    @Inject(method = "getModel", at = @At("HEAD"), cancellable = true)
    private void localskin$model(CallbackInfoReturnable<String> cir) {
        String model = SkinManager.getModel(((AbstractClientPlayerEntity) (Object) this).getUuid());
        if (model != null) cir.setReturnValue(model);
    }
}
