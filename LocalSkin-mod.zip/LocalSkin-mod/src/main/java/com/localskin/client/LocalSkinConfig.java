package com.localskin.client;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;

/** Запоминает выбранный скин между запусками игры (config/localskin.json). */
public final class LocalSkinConfig {
    public static String selected = null;
    public static boolean slim = false;

    private LocalSkinConfig() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("localskin.json");
    }

    public static void load() {
        try {
            Path f = file();
            if (!Files.exists(f)) return;
            JsonObject o = JsonParser.parseString(Files.readString(f)).getAsJsonObject();
            if (o.has("selected") && !o.get("selected").isJsonNull()) {
                selected = o.get("selected").getAsString();
            }
            slim = o.has("slim") && o.get("slim").getAsBoolean();
        } catch (Exception ignored) {
        }
    }

    public static void save() {
        try {
            JsonObject o = new JsonObject();
            if (selected != null) o.addProperty("selected", selected);
            o.addProperty("slim", slim);
            Files.writeString(file(), o.toString());
        } catch (Exception ignored) {
        }
    }
}
