package com.localskin.client;

import com.localskin.LocalSkinMod;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.util.Identifier;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/** Хранит подменённые скины игроков (включая вас) и их текстуры. */
public final class SkinManager {
    private record Entry(Identifier id, String model) {}

    private static final Map<UUID, Entry> SKINS = new HashMap<>();
    private static int counter = 0;

    private SkinManager() {}

    public static Identifier getTexture(UUID uuid) {
        Entry e = SKINS.get(uuid);
        return e == null ? null : e.id();
    }

    public static String getModel(UUID uuid) {
        Entry e = SKINS.get(uuid);
        return e == null ? null : e.model();
    }

    public static Identifier register(NativeImage image) {
        Identifier id = new Identifier(LocalSkinMod.MOD_ID, "skins/" + (counter++));
        MinecraftClient.getInstance().getTextureManager().registerTexture(id, new NativeImageBackedTexture(image));
        return id;
    }

    public static void unregister(Identifier id) {
        MinecraftClient.getInstance().getTextureManager().destroyTexture(id);
    }

    public static void apply(UUID uuid, String model, NativeImage image) {
        remove(uuid);
        SKINS.put(uuid, new Entry(register(image), model));
    }

    public static void remove(UUID uuid) {
        Entry e = SKINS.remove(uuid);
        if (e != null) unregister(e.id());
    }

    public static void clearAll() {
        for (Entry e : new ArrayList<>(SKINS.values())) unregister(e.id());
        SKINS.clear();
    }

    /** Применить скин, пришедший по сети (пустой массив = сброс). */
    public static void applyBytes(UUID uuid, String model, byte[] data) {
        if (data.length == 0) {
            remove(uuid);
            return;
        }
        try {
            apply(uuid, "slim".equals(model) ? "slim" : "default", decode(data));
        } catch (Exception ignored) {
        }
    }

    /** Читает PNG, приводит к 64x64 как это делает ваниль. */
    public static NativeImage decode(byte[] raw) throws IOException {
        NativeImage src = NativeImage.read(new ByteArrayInputStream(raw));
        int w = src.getWidth();
        int h = src.getHeight();
        if (w != 64 || (h != 64 && h != 32)) {
            src.close();
            throw new IOException("Skin must be 64x64 or 64x32 (got " + w + "x" + h + ")");
        }
        NativeImage out = src;
        if (h == 32) {
            out = new NativeImage(64, 64, true);
            out.fillRect(0, 0, 64, 64, 0);
            for (int y = 0; y < 32; y++) {
                for (int x = 0; x < 64; x++) {
                    out.setColor(x, y, src.getColor(x, y));
                }
            }
            src.close();
            out.copyRect(4, 16, 16, 32, 4, 4, true, false);
            out.copyRect(8, 16, 16, 32, 4, 4, true, false);
            out.copyRect(0, 20, 24, 32, 4, 12, true, false);
            out.copyRect(4, 20, 16, 32, 4, 12, true, false);
            out.copyRect(8, 20, 8, 32, 4, 12, true, false);
            out.copyRect(12, 20, 16, 32, 4, 12, true, false);
            out.copyRect(44, 16, -8, 32, 4, 4, true, false);
            out.copyRect(48, 16, -8, 32, 4, 4, true, false);
            out.copyRect(40, 20, 0, 32, 4, 12, true, false);
            out.copyRect(44, 20, -8, 32, 4, 12, true, false);
            out.copyRect(48, 20, -16, 32, 4, 12, true, false);
            out.copyRect(52, 20, -8, 32, 4, 12, true, false);
        }
        // Базовый слой скина не должен быть прозрачным
        stripAlpha(out, 0, 0, 32, 16);
        stripAlpha(out, 0, 16, 64, 32);
        stripAlpha(out, 16, 48, 48, 64);
        return out;
    }

    private static void stripAlpha(NativeImage img, int x0, int y0, int x1, int y1) {
        for (int x = x0; x < x1; x++) {
            for (int y = y0; y < y1; y++) {
                img.setColor(x, y, img.getColor(x, y) | 0xFF000000);
            }
        }
    }

    /** Байты для отправки по сети, либо null если файл слишком большой. */
    public static byte[] prepareShared(byte[] raw) {
        if (raw.length <= LocalSkinMod.MAX_BYTES) return raw;
        try {
            BufferedImage bi = ImageIO.read(new ByteArrayInputStream(raw));
            if (bi == null) return null;
            ByteArrayOutputStream bos = new ByteArrayOutputStream();
            ImageIO.write(bi, "png", bos);
            byte[] r = bos.toByteArray();
            return r.length <= LocalSkinMod.MAX_BYTES ? r : null;
        } catch (Exception e) {
            return null;
        }
    }
}
