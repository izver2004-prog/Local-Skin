package com.localskin.client;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.texture.NativeImageBackedTexture;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public class SkinSelectScreen extends Screen {
    private SkinList list;
    private Text status = Text.empty();
    private boolean slim = LocalSkinConfig.slim;
    private Identifier previewId;
    private String previewName;
    private boolean folderOk;
    private final List<String> files = new ArrayList<>();

    public SkinSelectScreen() {
        super(Text.translatable("localskin.title"));
    }

    @Override
    protected void init() {
        Path dir = LocalSkinClient.skinDir();
        folderOk = Files.isDirectory(dir);
        files.clear();

        int bw = (width - 40) / 3;
        int x0 = 10;
        int x1 = 20 + bw;
        int x2 = 30 + 2 * bw;
        int row1 = height - 52;
        int row2 = height - 28;

        if (!folderOk) {
            addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.create_folder"), b -> createFolder())
                    .dimensions(width / 2 - 100, height / 2 + 10, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.done"), b -> close())
                    .dimensions(width / 2 - 100, row2, 200, 20).build());
            return;
        }

        try (Stream<Path> s = Files.list(dir)) {
            s.filter(Files::isRegularFile)
                    .map(p -> p.getFileName().toString())
                    .filter(n -> n.toLowerCase(Locale.ROOT).endsWith(".png"))
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .forEach(files::add);
        } catch (IOException e) {
            status = Text.translatable("localskin.status.error", String.valueOf(e.getMessage()));
        }

        list = new SkinList(this, client, width / 2, height, 36, height - 58);
        String target = previewName != null ? previewName : LocalSkinConfig.selected;
        for (String f : files) {
            SkinList.SkinEntry entry = new SkinList.SkinEntry(this, list, f);
            list.add(entry);
            if (f.equals(target)) {
                list.setSelected(entry);
                if (previewName == null) loadPreview(f);
            }
        }
        addDrawableChild(list);

        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.apply"), b -> applySelected())
                .dimensions(x0, row1, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.reset"), b -> status = LocalSkinClient.reset())
                .dimensions(x1, row1, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(modelLabel(), b -> {
            slim = !slim;
            b.setMessage(modelLabel());
        }).dimensions(x2, row1, bw, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.open_folder"), b -> Util.getOperatingSystem().open(dir.toFile()))
                .dimensions(x0, row2, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.refresh"), b -> {
            clearChildren();
            init();
        }).dimensions(x1, row2, bw, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.done"), b -> close())
                .dimensions(x2, row2, bw, 20).build());
    }

    private Text modelLabel() {
        return Text.translatable(slim ? "localskin.model.slim" : "localskin.model.classic");
    }

    private void createFolder() {
        try {
            Files.createDirectories(LocalSkinClient.skinDir());
            status = Text.empty();
        } catch (IOException e) {
            status = Text.translatable("localskin.status.folder_error", String.valueOf(e.getMessage()));
        }
        clearChildren();
        init();
    }

    void onSelected(String name) {
        loadPreview(name);
    }

    void applySelected() {
        SkinList.SkinEntry e = list == null ? null : list.getSelectedOrNull();
        if (e == null) {
            status = Text.translatable("localskin.status.select_first");
            return;
        }
        status = LocalSkinClient.apply(e.name, slim);
    }

    private void loadPreview(String name) {
        if (name.equals(previewName) && previewId != null) return;
        if (previewId != null) {
            SkinManager.unregister(previewId);
            previewId = null;
        }
        previewName = name;
        try {
            byte[] raw = Files.readAllBytes(LocalSkinClient.skinDir().resolve(name));
            NativeImage img = SkinManager.decode(raw);
            previewId = SkinManager.register(img);
        } catch (Exception e) {
            status = Text.translatable("localskin.status.error", String.valueOf(e.getMessage()));
        }
    }

    @Override
    public void removed() {
        if (previewId != null) {
            SkinManager.unregister(previewId);
            previewId = null;
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (LocalSkinClient.openKey != null && LocalSkinClient.openKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        context.drawCenteredTextWithShadow(tr, title, width / 2, 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(tr, status, width / 2, 22, 0xFFFF55);

        if (!folderOk) {
            context.drawCenteredTextWithShadow(tr, Text.translatable("localskin.folder_missing"), width / 2, height / 2 - 40, 0xFF5555);
            int y = height / 2 - 26;
            for (OrderedText line : tr.wrapLines(Text.translatable("localskin.folder_hint"), width - 40)) {
                context.drawCenteredTextWithShadow(tr, line, width / 2, y, 0xCCCCCC);
                y += 10;
            }
            return;
        }

        if (files.isEmpty()) {
            int y = height / 2 - 20;
            int cx = width / 4;
            context.drawCenteredTextWithShadow(tr, Text.translatable("localskin.empty"), cx, y, 0xFFFFFF);
            y += 12;
            for (OrderedText line : tr.wrapLines(Text.literal(LocalSkinClient.skinDir().toString()), width / 2 - 20)) {
                context.drawCenteredTextWithShadow(tr, line, cx, y, 0xAAAAAA);
                y += 10;
            }
        }

        if (previewId != null) {
            int areaX = width / 2 + 10;
            int areaW = width / 2 - 20;
            int areaY = 36;
            int areaH = height - 58 - 36;
            int s = Math.max(16, Math.min(areaW, areaH));
            int px = areaX + (areaW - s) / 2;
            int py = areaY + (areaH - s) / 2;
            context.fill(px - 2, py - 2, px + s + 2, py + s + 2, 0xA0000000);
            context.drawTexture(previewId, px, py, s, s, 0.0F, 0.0F, 64, 64, 64, 64);
        }
    }

    // ------------------------------------------------------------------

    static class SkinList extends AlwaysSelectedEntryListWidget<SkinList.SkinEntry> {
        SkinList(SkinSelectScreen screen, MinecraftClient mc, int width, int height, int top, int bottom) {
            super(mc, width, height, top, bottom, 18);
        }

        void add(SkinEntry e) {
            addEntry(e);
        }

        @Override
        public int getRowWidth() {
            return width - 24;
        }

        @Override
        protected int getScrollbarPositionX() {
            return width - 8;
        }

        static class SkinEntry extends AlwaysSelectedEntryListWidget.Entry<SkinEntry> {
            final SkinSelectScreen screen;
            final SkinList list;
            final String name;
            private long lastClick = 0;

            SkinEntry(SkinSelectScreen screen, SkinList list, String name) {
                this.screen = screen;
                this.list = list;
                this.name = name;
            }

            @Override
            public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight,
                               int mouseX, int mouseY, boolean hovered, float tickDelta) {
                TextRenderer tr = MinecraftClient.getInstance().textRenderer;
                boolean active = name.equals(LocalSkinConfig.selected);
                String shown = tr.trimToWidth(name, entryWidth - 8);
                context.drawTextWithShadow(tr, shown, x + 3, y + 3, active ? 0x55FF55 : 0xFFFFFF);
            }

            public Text getNarration() {
                return Text.literal(name);
            }

            @Override
            public boolean mouseClicked(double mouseX, double mouseY, int button) {
                if (button != 0) return false;
                list.setSelected(this);
                screen.onSelected(name);
                long now = Util.getMeasuringTimeMs();
                if (now - lastClick < 300) {
                    screen.applySelected();
                }
                lastClick = now;
                return true;
            }
        }
    }
}
