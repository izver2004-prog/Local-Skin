package com.localskin.client;

import com.mojang.blaze3d.systems.RenderSystem;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.AlwaysSelectedEntryListWidget;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.text.OrderedText;
import net.minecraft.text.Text;
import net.minecraft.util.Identifier;
import net.minecraft.util.Util;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.stream.Stream;

public class SkinSelectScreen extends Screen {
    private SkinList list;
    private Text status = Text.empty();
    private boolean slim = LocalSkinConfig.slim;
    private Identifier previewId;
    private String previewName;
    private boolean folderOk;
    private final List<String> files = new ArrayList<>();
    private final List<String> otherFiles = new ArrayList<>();

    // геометрия
    private int listLeft, listW, rightX, rightW, previewBottom;

    public SkinSelectScreen() {
        super(Text.translatable("localskin.title"));
    }

    @Override
    protected void init() {
        Path dir = LocalSkinClient.skinDir();
        folderOk = Files.isDirectory(dir);
        files.clear();
        otherFiles.clear();

        int rowDone = height - 28;
        if (!folderOk) {
            addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.create_folder"), b -> createFolder())
                    .dimensions(width / 2 - 100, height / 2 + 10, 200, 20).build());
            addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.done"), b -> close())
                    .dimensions(width / 2 - 100, rowDone, 200, 20).build());
            return;
        }

        try (Stream<Path> s = Files.list(dir)) {
            s.filter(Files::isRegularFile)
                    .map(p -> p.getFileName().toString())
                    .sorted(String.CASE_INSENSITIVE_ORDER)
                    .forEach(n -> {
                        if (n.toLowerCase(Locale.ROOT).endsWith(".png")) files.add(n);
                        else otherFiles.add(n);
                    });
        } catch (IOException e) {
            status = Text.translatable("localskin.status.error", String.valueOf(e.getMessage()));
        }

        listLeft = 10;
        listW = Math.max(120, (int) (width * 0.42));
        rightX = listLeft + listW + 10;
        rightW = width - rightX - 10;

        int half = (rightW - 4) / 2;
        int r4 = height - 28;
        int r3 = height - 52;
        int r2 = height - 76;
        int r1 = height - 100;
        previewBottom = r1 - 6;

        list = new SkinList(client, listW, height, 36, height - 10);
        list.setLeftPos(listLeft);
        String target = previewName != null ? previewName : LocalSkinConfig.selected;
        for (String f : files) {
            SkinList.SkinEntry entry = new SkinList.SkinEntry(this, list, f);
            list.add(entry);
            if (f.equals(target)) {
                list.setSelected(entry);
                if (previewName == null || previewId == null) loadPreview(f);
            }
        }
        addDrawableChild(list);

        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.apply"), b -> applySelected())
                .dimensions(rightX, r1, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.reset"), b -> status = LocalSkinClient.reset())
                .dimensions(rightX + half + 4, r1, half, 20).build());
        addDrawableChild(ButtonWidget.builder(modelLabel(), b -> {
            slim = !slim;
            b.setMessage(modelLabel());
        }).dimensions(rightX, r2, rightW, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.open_folder"), b -> Util.getOperatingSystem().open(dir.toFile()))
                .dimensions(rightX, r3, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.refresh"), b -> {
            clearChildren();
            init();
        }).dimensions(rightX + half + 4, r3, half, 20).build());
        addDrawableChild(ButtonWidget.builder(Text.translatable("localskin.done"), b -> close())
                .dimensions(rightX, r4, rightW, 20).build());
    }

    private Text modelLabel() {
        return Text.translatable(slim ? "localskin.model.slim" : "localskin.model.classic");
    }

    private void createFolder() {
        try {
            Files.createDirectories(LocalSkinClient.skinDir());
            status = Text.empty();
        } catch (IOException e) {
            status = Text.translatable("localskin.status.folder_error", String.valueOf(e.getMessage()));
        }
        clearChildren();
        init();
    }

    void onSelected(String name) {
        loadPreview(name);
    }

    void applySelected() {
        SkinList.SkinEntry e = list == null ? null : list.getSelectedOrNull();
        if (e == null) {
            status = Text.translatable("localskin.status.select_first");
            return;
        }
        status = LocalSkinClient.apply(e.name, slim);
    }

    private void loadPreview(String name) {
        if (previewId != null) {
            SkinManager.unregister(previewId);
            previewId = null;
        }
        previewName = name;
        try {
            byte[] raw = Files.readAllBytes(LocalSkinClient.skinDir().resolve(name));
            NativeImage img = SkinManager.decode(raw);
            previewId = SkinManager.register(img);
        } catch (Exception e) {
            status = Text.translatable("localskin.status.error", String.valueOf(e.getMessage()));
        }
    }

    @Override
    public void removed() {
        if (previewId != null) {
            SkinManager.unregister(previewId);
            previewId = null;
        }
    }

    @Override
    public boolean keyPressed(int keyCode, int scanCode, int modifiers) {
        if (LocalSkinClient.openKey != null && LocalSkinClient.openKey.matchesKey(keyCode, scanCode)) {
            close();
            return true;
        }
        return super.keyPressed(keyCode, scanCode, modifiers);
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context);
        super.render(context, mouseX, mouseY, delta);
        TextRenderer tr = textRenderer;
        context.drawCenteredTextWithShadow(tr, title, width / 2, 8, 0xFFFFFF);
        context.drawCenteredTextWithShadow(tr, status, width / 2, 22, 0xFFFF55);

        if (!folderOk) {
            context.drawCenteredTextWithShadow(tr, Text.translatable("localskin.folder_missing"), width / 2, height / 2 - 40, 0xFF5555);
            int y = height / 2 - 26;
            for (OrderedText line : tr.wrapLines(Text.translatable("localskin.folder_hint"), width - 40)) {
                context.drawCenteredTextWithShadow(tr, line, width / 2, y, 0xCCCCCC);
                y += 10;
            }
            return;
        }

        // ---- пустой список: объясняем, что лежит в папке ----
        if (files.isEmpty()) {
            int cx = listLeft + listW / 2;
            int y = 48;
            for (OrderedText line : tr.wrapLines(Text.translatable("localskin.empty"), listW - 12)) {
                context.drawCenteredTextWithShadow(tr, line, cx, y, 0xFFFFFF);
                y += 10;
            }
            y += 4;
            for (OrderedText line : tr.wrapLines(Text.literal(LocalSkinClient.skinDir().toString()), listW - 12)) {
                context.drawCenteredTextWithShadow(tr, line, cx, y, 0xAAAAAA);
                y += 10;
            }
            if (!otherFiles.isEmpty()) {
                y += 6;
                String names = String.join(", ", otherFiles.subList(0, Math.min(4, otherFiles.size())));
                for (OrderedText line : tr.wrapLines(Text.translatable("localskin.other_files", names), listW - 12)) {
                    context.drawCenteredTextWithShadow(tr, line, cx, y, 0xFF8888);
                    y += 10;
                }
            }
        }

        // ---- правая панель: превью ----
        int panelTop = 36;
        context.fill(rightX, panelTop, rightX + rightW, previewBottom, 0x88000000);
        if (previewId != null && previewName != null) {
            String shown = tr.trimToWidth(previewName, rightW - 8);
            context.drawCenteredTextWithShadow(tr, shown, rightX + rightW / 2, panelTop + 4, 0xFFFFFF);
            int areaY = panelTop + 16;
            int areaH = previewBottom - areaY - 4;
            int aw = slim ? 3 : 4;
            int figUnitsW = 2 * aw + 8;
            int k = Math.max(1, Math.min(areaH / 32, (rightW - 8) / (figUnitsW * 2 + 4)));
            int figW = figUnitsW * k;
            int totalW = figW * 2 + 4 * k;
            int sx = rightX + (rightW - totalW) / 2;
            int sy = areaY + (areaH - 32 * k) / 2;
            RenderSystem.enableBlend();
            drawFigure(context, previewId, sx, sy, k, false);
            drawFigure(context, previewId, sx + figW + 4 * k, sy, k, true);
        } else {
            context.drawCenteredTextWithShadow(tr, Text.translatable("localskin.select_hint"),
                    rightX + rightW / 2, (panelTop + previewBottom) / 2 - 4, 0xAAAAAA);
        }
    }

    // ------------------------------------------------------------------
    // Плоское превью скина (вид спереди и сзади)

    private void part(DrawContext c, Identifier id, int x, int y, int k, int u, int v, int w, int h) {
        c.drawTexture(id, x, y, w * k, h * k, (float) u, (float) v, w, h, 64, 64);
    }

    private void drawFigure(DrawContext c, Identifier id, int x, int y, int k, boolean back) {
        int aw = slim ? 3 : 4;
        int bx = x + aw * k;
        int by = y + 8 * k;
        int ly = y + 20 * k;

        // ноги
        drawLeg(c, id, bx, ly, k, !back, back);
        drawLeg(c, id, bx + 4 * k, ly, k, back, back);
        // тело
        part(c, id, bx, by, k, back ? 32 : 20, 20, 8, 12);
        part(c, id, bx, by, k, back ? 32 : 20, 36, 8, 12);
        // руки (слева от зрителя спереди — правая рука персонажа)
        drawArm(c, id, x, by, k, aw, !back, back);
        drawArm(c, id, bx + 8 * k, by, k, aw, back, back);
        // голова
        part(c, id, bx, y, k, back ? 24 : 8, 8, 8, 8);
        part(c, id, bx, y, k, back ? 56 : 40, 8, 8, 8);
    }

    private void drawArm(DrawContext c, Identifier id, int x, int y, int k, int aw, boolean rightArm, boolean back) {
        if (rightArm) {
            int u = back ? (slim ? 51 : 52) : 44;
            part(c, id, x, y, k, u, 20, aw, 12);
            part(c, id, x, y, k, u, 36, aw, 12);
        } else {
            int u = back ? (slim ? 43 : 44) : 36;
            int u2 = back ? (slim ? 59 : 60) : 52;
            part(c, id, x, y, k, u, 52, aw, 12);
            part(c, id, x, y, k, u2, 52, aw, 12);
        }
    }

    private void drawLeg(DrawContext c, Identifier id, int x, int y, int k, boolean rightLeg, boolean back) {
        if (rightLeg) {
            int u = back ? 12 : 4;
            part(c, id, x, y, k, u, 20, 4, 12);
            part(c, id, x, y, k, u, 36, 4, 12);
        } else {
            int u = back ? 28 : 20;
            int u2 = back ? 12 : 4;
            part(c, id, x, y, k, u, 52, 4, 12);
            part(c, id, x, y, k, u2, 52, 4, 12);
        }
    }

    // ------------------------------------------------------------------

    static class SkinList extends AlwaysSelectedEntryListWidget<SkinList.SkinEntry> {
        SkinList(MinecraftClient mc, int width, int height, int top, int bottom) {
            super(mc, width, height, top, bottom, 18);
        }

        void add(SkinEntry e) {
            addEntry(e);
        }

        @Override
        public int getRowWidth() {
            return width - 16;
        }

        @Override
        protected int getScrollbarPositionX() {
            return left + width - 6;
        }

        static class SkinEntry extends AlwaysSelectedEntryListWidget.Entry<SkinEntry> {
            final SkinSelectScreen screen;
            final SkinList list;
            final String name;
            private long lastClick = 0;

            SkinEntry(SkinSelectScreen screen, SkinList list, String name) {
                this.screen = screen;
                this.list = list;
                this.name = name;
            }

            @Override
            public void render(DrawContext context, int index, int y, int x, int entryWidth, int entryHeight,
                               int mouseX, int mouseY, boolean hovered, float tickDelta) {
                TextRenderer tr = MinecraftClient.getInstance().textRenderer;
                boolean active = name.equals(LocalSkinConfig.selected);
                String shown = tr.trimToWidth(name, entryWidth - 8);
                context.drawTextWithShadow(tr, shown, x + 3, y + 3, active ? 0x55FF55 : 0xFFFFFF);
            }

            public Text getNarration() {
                return Text.literal(name);
            }

            @Override
            public boolean mouseClicked(double mouseX, double mouseY, int button) {
                if (button != 0) return false;
                list.setSelected(this);
                screen.onSelected(name);
                long now = Util.getMeasuringTimeMs();
                if (now - lastClick < 300) {
                    screen.applySelected();
                }
                lastClick = now;
                return true;
            }
        }
    }
}
