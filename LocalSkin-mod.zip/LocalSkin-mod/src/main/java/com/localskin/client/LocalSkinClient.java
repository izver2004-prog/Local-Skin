package com.localskin.client;

import com.localskin.LocalSkinMod;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.PacketByteBufs;
import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.texture.NativeImage;
import net.minecraft.client.util.InputUtil;
import net.minecraft.network.PacketByteBuf;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.UUID;

public class LocalSkinClient implements ClientModInitializer {
    public static KeyBinding openKey;
    private static int pendingJoin = -1;

    /** Папка LocalSkin в папке игры (там где saves, mods, config). */
    public static Path skinDir() {
        return FabricLoader.getInstance().getGameDir().resolve("LocalSkin");
    }

    @Override
    public void onInitializeClient() {
        LocalSkinConfig.load();

        openKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.localskin.open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_B, "key.categories.localskin"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.wasPressed()) {
                if (client.world != null && client.currentScreen == null) {
                    client.setScreen(new SkinSelectScreen());
                }
            }
            if (pendingJoin > 0) {
                pendingJoin--;
                if (pendingJoin == 0 && client.player != null) {
                    onJoinReady();
                }
            }
        });

        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> pendingJoin = 40);
        ClientPlayConnectionEvents.DISCONNECT.register((handler, client) -> {
            pendingJoin = -1;
            SkinManager.clearAll();
        });

        ClientPlayNetworking.registerGlobalReceiver(LocalSkinMod.SYNC, (client, handler, buf, sender) -> {
            UUID uuid = buf.readUuid();
            String model = buf.readString(16);
            byte[] data = buf.readByteArray(LocalSkinMod.MAX_BYTES);
            client.execute(() -> {
                if (client.player != null && client.player.getUuid().equals(uuid)) return;
                SkinManager.applyBytes(uuid, model, data);
            });
        });
    }

    private static void onJoinReady() {
        if (ClientPlayNetworking.canSend(LocalSkinMod.HELLO)) {
            ClientPlayNetworking.send(LocalSkinMod.HELLO, PacketByteBufs.create());
        }
        if (LocalSkinConfig.selected != null) {
            apply(LocalSkinConfig.selected, LocalSkinConfig.slim);
        }
    }

    /** Применяет файл из папки LocalSkin и рассылает его другим игрокам с модом. */
    public static Text apply(String fileName, boolean slim) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return Text.translatable("localskin.status.no_world");
        Path file = skinDir().resolve(fileName);
        if (!Files.isRegularFile(file)) return Text.translatable("localskin.status.missing", fileName);
        try {
            byte[] raw = Files.readAllBytes(file);
            NativeImage img = SkinManager.decode(raw);
            String model = slim ? "slim" : "default";
            SkinManager.apply(mc.player.getUuid(), model, img);
            LocalSkinConfig.selected = fileName;
            LocalSkinConfig.slim = slim;
            LocalSkinConfig.save();
            byte[] shared = SkinManager.prepareShared(raw);
            if (shared == null) return Text.translatable("localskin.status.applied_local_only", fileName);
            sendSet(model, shared);
            return Text.translatable("localskin.status.applied", fileName);
        } catch (Exception e) {
            return Text.translatable("localskin.status.error", String.valueOf(e.getMessage()));
        }
    }

    public static Text reset() {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player != null) SkinManager.remove(mc.player.getUuid());
        LocalSkinConfig.selected = null;
        LocalSkinConfig.save();
        sendSet("default", new byte[0]);
        return Text.translatable("localskin.status.reset");
    }

    private static void sendSet(String model, byte[] data) {
        if (!ClientPlayNetworking.canSend(LocalSkinMod.SET)) return;
        PacketByteBuf buf = PacketByteBufs.create();
        buf.writeString(model);
        buf.writeByteArray(data);
        ClientPlayNetworking.send(LocalSkinMod.SET, buf);
    }
}
